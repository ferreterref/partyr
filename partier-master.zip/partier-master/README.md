# partier
package for L1 metric choice analysis
