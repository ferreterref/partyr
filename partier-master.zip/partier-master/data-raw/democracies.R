democracies<-read.csv("democracies.csv",header=TRUE)
devtools::use_data(democracies, overwrite = T, internal = TRUE)
#run the above lines to get new dta file and then move it to data folder!!
