#' Taxicab Calculation
#'
#' This function calculates the taxicab (i.e. Manhattan or L1) distance between two coordinate points.
#' @param x vector representing first coordinate
#' @param y vector representing second coordinate
#' @keywords taxicab
#' @export
#' @examples
#' taxicab(c(1,2,3),c(4,5,6))
taxicab<-function(x,y){
  if( length(x)!=length(y)) stop('x and y must have same length')
  ind.dist<-rep(-1,length(x))
  for(i in 1:length(x)){
    ind.dist[i]<-abs(x[i]-y[i])
  }
  return(sum(ind.dist))
}




#' Duplicated Minimum Detection
#'
#' This function detects whether an inputted vector has a unique minimum value.
#' Returns a 0 if minimum is unique and a 1 if minimum is not unique.
#' @param x vector
#' @keywords duplicate
#' @export
#' @examples
#' duplicate_min(c(1,2,3))
#' duplicate_min(c(1,1,3))
duplicate_min<-function(x){
  x2<-x[x==min(x)]
  ifelse(length(x2)>1,1,0)
}




#' All possible party distances
#'
#' This function generates distances between all possible n-dimensioned tuples and all inputed centers and determines "closest" centers.
#' @param policies matrix representing parties' policy positions, with positions being rows and parties being columns
#' @param scale.upper number representing upper bound on scales that all dimensions are measured on. Lower bound is 1.
#' @param col vector of colors equal to number of parties (columns of policies matirx)
#' @param pch vector of length 3 signifying point type for party centers, parties' territories, and disputed territories, used for plotting
#' @param cex vector of length 2 - sizes of party center and territory points
#' @keywords distances
#' @export
#' @examples
coordinate_distances<-function(policies,scale.upper=10,col=grDevices::rainbow(nrow(policies)),
                               pch=c(16,15,0),cex=c(6,3)){
  numpolicies=nrow(policies)
  numparties=ncol(policies)
  for(i in 1:nrow(policies)){
    if( any(policies[i,] > scale.upper) ) stop('policies must not exceed scale.upper')
    if( any(policies[i,] < 1) ) stop('policies must be 1 or larger')
  }
  policies<-round(policies)
  record<-matrix(-1,ncol=numpolicies+numparties,nrow=scale.upper^numpolicies)
  coord<-rep(1,numpolicies)
  coorddec<-rep(0,numpolicies)
  coordadd<-coorddec
  for(i in 1:numpolicies){
    coordadd[i]<-1/(scale.upper^(numpolicies-i))
  }
  for(i in 1:(scale.upper^numpolicies)){
    coorddec<-coorddec+coordadd
    coord<-ceiling(coorddec-1/(scale.upper^(numpolicies+1)))
    coord<-((coord-1)%%scale.upper)+1
    record[i,1:numpolicies]<-coord
    for(j in 1:numparties){
      record[i,numpolicies+j]<-taxicab(as.vector(record[i,1:numpolicies]),as.vector(policies[1:numpolicies,j]))
    }
  }
  record<-cbind(record,rep(0,nrow(record)))
  for(i in 1:nrow(record)){
    if(duplicate_min(as.vector(record[i,(numpolicies+1):(numpolicies+numparties)]))==1){
      record[i,numparties+numpolicies+1]<-0
    } else {
      record[i,numparties+numpolicies+1]<-which.min(record[i,(numpolicies+1):(numpolicies+numparties)])
    }
  }
  record<-list("matrix"=record,"colors"=col,"pch"=pch,"cex"=cex)
  class(record)<-append("PartyMatrix",class(record))
  record

}







#' Plotting Territory Matrix
#'
#' This function creates simultaneous, policy dimension-pairwise plots, as created with plot_territories
#' @param object matrix output from coordinate_distances
#' @param lab vector containing policy names in order
#' @param ... Arguments to be passed to methods. See ?plot for more information.
#' @keywords taxicab
#' @export
#' @examples
plot_matrix<-function(object,lab=c("1","2","3","4","5","6"),...){
  policies<-new_policies(object)
  scale.upper<-max(object$matrix[,1])
  graphics::par(mfrow=c(nrow(policies),nrow(policies)))
  for(i in 1:nrow(policies)){
    for(j in 1:nrow(policies)){
      graphics::plot(coordinate_distances(policies[c(i,j),],scale.upper=scale.upper),xlab=lab[i],ylab=lab[j],...)
    }
  }
}




#' Summarizing parties' territories
#'
#' This function gives a well organized summary of parties' territories
#' @param object matrix output from coordinate_distances
#' @param ... Arguments to be passed to methods. See ?summary for more information.
#' @keywords summary
#' @export
#' @examples
summary.PartyMatrix<-function(object,...){
  winner<-summary(as.factor(object$matrix[,ncol(object$matrix)]))
  numpolicies<-partypolicy_numbers(object)$policy_number
  distances<-summary(object$matrix[,(numpolicies+1):(ncol(object$matrix)-1)],...)
  my_list<-list("distances"=distances,"territory_totals"=winner)
  my_list
}




#' Policy and Party Numbers
#'
#' This function gives the number of parties and policy dimensions used to create PartyMatrix object
#' @param object matrix output from coordinate_distances
#' @keywords numbers
#' @export
#' @examples
partypolicy_numbers<-function(object){
  scale.upper<-max(object$matrix[,1])
  numpolicies<-log(nrow(object$matrix),base=scale.upper)
  numparties<-ncol(object$matrix)-numpolicies-1
  my_list<-list("party_number"=numparties,"policy_number"=numpolicies)
  my_list
}






#' Plotting Party Territories
#'
#' This function plots parties' "territories" based on inputted party platforms
#' @param x matrix output from coordinate_distances
#' @param ... Arguments to be passed to methods. See ?plot for more information.
#' @keywords taxicab
#' @export
#' @examples
plot.PartyMatrix<-function(x,...){
  if(class(x)[1]!=c("PartyMatrix")) stop("Should only use this function to plot PartyMatrix xs")
  policies<-new_policies(x)
  if(nrow(policies)!=2) stop('Can only plot on two policy dimensions')
  scale.upper<-max(x$matrix[,1])
  graphics::plot(policies[1,1],policies[2,1],xlim=c(1,scale.upper),ylim=c(1,scale.upper),type='p',
                 pch=x$pch[1],col=x$col[1],cex=x$cex[1],...)
  for(i in 2:ncol(policies)){
    graphics::points(policies[1,i],policies[2,i],pch=x$pch[1],col=x$col[i],cex=x$cex[1])
  }
  mat<-coordinate_distances(policies=policies,scale.upper=scale.upper)$matrix
  for(i in 1:scale.upper^2){
    if (mat[i,ncol(mat)]==0){
      graphics::points(mat[i,1],mat[i,2],pch=x$pch[3],col="black")
    } else {
      graphics::points(mat[i,1],mat[i,2],pch=x$pch[2],col=x$col[mat[i,ncol(mat)]],cex=x$cex[2])
    }
  }
}




#' Forming policies from PartyMatrix object
#'
#' This function retrofits the original policy matrix from a PartyMatrix object created with coordinate_distances.
#' @param object matrix output from coordinate_distances
#' @keywords PartyMatrix
#' @export
#' @examples
new_policies<-function(object){
  scale.upper<-max(object$matrix[,1])
  numpolicies=partypolicy_numbers(object)$policy_number
  numparties=partypolicy_numbers(object)$party_number
  policies<-matrix(rep(-1,numparties*numpolicies),nrow=numpolicies)
  for(i in (numpolicies+1):(ncol(object$matrix)-1)){
    policies[,(i-numpolicies)]<-object$matrix[which(object$matrix[,i]==0),1:numpolicies]
  }
  policies
}


