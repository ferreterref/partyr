library(testthat)
library(partier)
test_check("partier")
